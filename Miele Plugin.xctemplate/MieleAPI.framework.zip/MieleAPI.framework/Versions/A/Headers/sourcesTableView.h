
#import <Cocoa/Cocoa.h>


/** \brief Q/R sources TableView */
@interface sourcesTableView : NSTableView
{
}

@end