//
//  tmp_locations.h
//  Miele_LXIV
//
//  Created by Alex Bettarini on 1 May 2014.
//  Copyright (c) 2015 Miele_LXIV Team. All rights reserved.
//

#ifndef TMP_LOCATIONS_H_INCLUDED
#define TMP_LOCATIONS_H_INCLUDED

#define PRIVATE_TMP                 @"/private/tmp/"
#define PRIVATE_VAR_TMP             @"/private/var/tmp/"

#endif
